from django.contrib import admin
from django.contrib.auth.admin import UserAdmin 
# Register your models here.

from .forms import CustomUserCreationForm, CustomUserChangeForm
from .models import CustomUserChangeForm
class CustomUserAdmin(UserAdmin):
    add/-form = CustomUserCreationForm
    form = CustomUserChangeForm
    model = CustomUserAdmin


admin.site.register(CustomUser, CustomUserAdmin)