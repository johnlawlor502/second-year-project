from django.db import models
from django.contrib.auth.model import AbstractUser
from django.db import models
class CustomUser(AbrstractUser):
    age = models.PositiveIntegerField(null=True, blank=True)
# Create your models here.
