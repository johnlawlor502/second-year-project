from django.urls import path

from .views import HomePageView, AboutPageView, Base2PageView, TorentPageView, TrDetailView, TrCreateView, TradUpdateView, TradDeleteView

urlpatterns = [
    path('', HomePageView.as_view(), name='home'),
    path('about/', AboutPageView.as_view(), name='about'),
    path('base2/', Base2PageView.as_view(), name='base2'),
    path('torent/', TorentPageView.as_view(), name='torent'),
    path('post/<int:pk>/', TrDetailView.as_view(), name='tr_post_detail'),
    path('post/new/', TrCreateView.as_view(), name='new_ad'),
    path('post/<int:pk>/edit/', TradUpdateView.as_view(), name='ad_edit'),
    path('post/<int:pk>/delete/', TradDeleteView.as_view(), name='ad_delete'),
]