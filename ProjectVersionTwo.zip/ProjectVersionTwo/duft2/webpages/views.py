from django.views.generic import TemplateView, ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

from .models import Post


class HomePageView(TemplateView):
    template_name = 'home.html'

class AboutPageView(TemplateView):
    template_name = 'about.html'

class Base2PageView(TemplateView):
    template_name = 'base2.html'

class TorentPageView(ListView):
    model = Post
    template_name = 'torent.html'
    context_object_name = 'all_posts_list'

class TrDetailView(DetailView): #tr is short for To Rent
    model = Post
    template_name = 'tr_post_detail.html'

class TrCreateView(CreateView):
    model = Post
    template_name = 'new_ad.html'
    fields = ['title', 'author', 'body']

class TradUpdateView(UpdateView):
    model = Post 
    template_name = 'ad_edit.html'
    fields = ['title', 'body']

class TradDeleteView(DeleteView):
    model = Post
    template_name = 'ad_delete.html'
    success_url = reverse_lazy('home')

